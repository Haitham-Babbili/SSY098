function some_string = hello_world()
    some_string = 'Hello world!';
end